function limpiarMarca(){
	$("#referenciaMarca").val("");
	$("#nombreMarca").val("");
}
function limpiarProducto(){
	$("#codigo").val("");
	$("#nombreProducto").val("");
	$("#talla").val("");
	$("#marca").val("");
	$("#cantidad").val("");
	$("#fecha").val("");
}
function peticionAjax(newUrl, dataSubmit){
	$.ajax({
		method:'POST',
		url: newUrl,
		data: dataSubmit,
		success: function(data){
			alert(data);
		},
		error: function(){
			alert("ha ocurrido un problema");
		}
	});
}
$(document).ready(function () {
//--------------------------------BOTONES DE NUESTRA MARCA-----------------------------
	$('#btnGuardarMarca').click(function(){
		$("input").trigger("blur");
		var ref= $("#referenciaMarca").val();
		var nom= $("#nombreMarca").val();
		if (($("input").hasClass("campErr"))|| nom.trim().length==0) {
			alert("Debes completar bien los campos!!");
		}else{
			peticionAjax('php/guardarM.php',{reference:ref, name:nom});
			limpiarMarca();
		}		
	});
	$('#btnEditarMarca').click(function(){
		$("input").trigger("blur");
		var ref= $("#referenciaMarca").val();
		var nom= $("#nombreMarca").val();
		if (($("input").hasClass("campErr"))|| nom.trim().length==0) {
			alert("Debes completar bien los campos!!");
		}else{
			peticionAjax('php/editarM.php',{ref:ref, nombre:nom});
			limpiarMarca();
		}
	});
	$('#btnEliminarMarca').click(function(){
		var codigo= prompt("Ingresa por favor la referencia de la marca a eliminar");
		if (isNaN(codigo) || codigo=="") {
			alert("Referencia debe ser numeros");
		}else{			
			peticionAjax('php/eliminarM.php',{ref:codigo});
		}
	});

//--------------------------------BOTONES DE NUESTRO PRODUCTO---------------------------
	$('#btnGuardarProducto').click(function(){
		$("input").trigger("blur");
		var cod= $("#codigo").val();
		var nombreP= $("#nombreProducto").val();
		var talla= $("#talla").val();
		var marca= $("#marca").val();
		var cantidad= $("#cantidad").val();
		var fecha= $("#fecha").val();
		if (($("input").hasClass("campErr"))|| nombreP.trim().length==0 || talla.trim().length==0 || marca.trim().length==0 || cantidad.trim().length==0 || fecha.trim().length==0) {
			alert("Debes completar bien los campos!!");
		}else{
			peticionAjax('php/guardarP.php',{codigo:cod, name:nombreP, talla:talla, marca:marca, cantidad:cantidad, fecha:fecha});
			limpiarProducto();
		}
	});
	$('#btnEditarProducto').click(function(){
		$("input").trigger("blur");
		var cod= $("#codigo").val();
		var nombreP= $("#nombreProducto").val();
		var talla= $("#talla").val();
		var marca= $("#marca").val();
		var cantidad= $("#cantidad").val();
		var fecha= $("#fecha").val();
		if (($("input").hasClass("campErr"))|| nombreP.trim().length==0 || talla.trim().length==0 || marca.trim().length==0 || cantidad.trim().length==0 || fecha.trim().length==0) {
			alert("Debes completar bien los campos!!");
		}else{
			peticionAjax('php/editarP.php',{codigo:cod, name:nombreP, talla:talla, marca:marca, cantidad:cantidad, fecha:fecha});
			limpiarProducto();
		}
	});
	$('#btnEliminarProducto').click(function(){
		var codigo= prompt("Ingresa por favor el codigo del producto a eliminar");
		if (isNaN(codigo) || codigo=="") {
			alert("Referencia debe ser numeros");
		}else{			
			peticionAjax('php/eliminarP.php',{cod:codigo});
		}
	});
//--------------------------------VERIFICACION DE TIPO DE DATOS--------------------------
	$("#referenciaMarca").blur(function(){
		if (isNaN($("#referenciaMarca").val())) {
			$(this).siblings(".campoErroneo").css("display","block");
			$(this).addClass("campErr");
		}else{
			$(this).removeClass("campErr");
		}	
	});
	$("input").focus(function(){
		$(this).siblings(".campoErroneo").css("display","none");
		$(this).removeClass("campErr");
	});	
	$("#codigo").blur(function(){
		if (isNaN($("#codigo").val())) {
			$(this).siblings(".campoErroneo").css("display","block");
			$(this).addClass("campErr");
		}else{
			$(this).removeClass("campErr");
		}	
	});
});