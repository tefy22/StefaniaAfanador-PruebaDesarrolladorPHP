<?php  

require 'conexion.php';

$con= new ConexionDB();

if ($con->conexion('almacen')=='OK') {
	$ref= $_POST['ref'];
	$nombre= $_POST['nombre'];
	$res= $con->buscarDatos('marca','referencia',$ref);
	if (mysqli_num_rows($res)==true) {
		$con->actualizarMarca($ref, $nombre);
		echo "Datos Actualizados Satisfactoriamente!";
	}else{
		echo "La marca no se encuentra registrada!";
	}
}else{
	echo "error en la conexion";
	$con->cerrarConexion();
}
?>