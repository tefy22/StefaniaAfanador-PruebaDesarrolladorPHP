<?php  

require 'conexion.php';

$con= new ConexionDB();

if ($con->conexion('almacen')=='OK') {
	$cod= $_POST['cod'];
	$res= $con->buscarDatos('producto','codigo',$cod);
	if (mysqli_num_rows($res)==true) {
		$con->eliminarProducto($cod);
		echo "Datos Eliminados Satisfactoriamente!";
	}else{
		echo "EL producto no se encuentra registrado!";
	}
}else{
	echo "error en la conexion";
	$con->cerrarConexion();
}

?>