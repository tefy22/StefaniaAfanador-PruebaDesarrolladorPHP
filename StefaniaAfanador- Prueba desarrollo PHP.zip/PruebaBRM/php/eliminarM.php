<?php  

require 'conexion.php';

$con= new ConexionDB();

if ($con->conexion('almacen')=='OK') {
	$ref= $_POST['ref'];
	$res= $con->buscarDatos('marca','referencia',$ref);
	if (mysqli_num_rows($res)==true) {
		$con->eliminarMarca($ref);
		echo "Datos Eliminados Satisfactoriamente!";
	}else{
		echo "La marca no se encuentra registrada!";
	}
}else{
	echo "error en la conexion";
	$con->cerrarConexion();
}

?>