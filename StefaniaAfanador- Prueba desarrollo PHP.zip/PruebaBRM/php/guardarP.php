<?php  

require 'conexion.php';

$con= new ConexionDB();

if ($con->conexion('almacen')=='OK') {
	$cod= $_POST['codigo'];
	$nombre= $_POST['name'];
	$talla= $_POST['talla'];
	$marca= $_POST['marca'];
	$canti= $_POST['cantidad'];
	$fecha= $_POST['fecha'];

	$res= $con->buscarDatos('producto','codigo',$cod);
	if (mysqli_num_rows($res)==true) {
		echo "El producto ya se encuentra registrado!";
	}else{
		$con->guardarProducto($cod, $nombre, $talla, $marca, $canti, $fecha);
		echo "Datos Guardados Satisfactoriamente!";
	}
	
}else{
	echo "error en la conexion";
	$con->cerrarConexion();
}

?>
