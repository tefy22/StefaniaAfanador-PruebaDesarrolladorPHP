<?php  


class ConexionDB{

	private $host;
	private $user;
	private $password;
	private $conexion;

	function __construct(){
		$this->host= 'localhost';
		$this->user= 'root';
		$this->password= '';
	}

	function conexion($bd){
		$this->conexion= new mysqli($this->host, $this->user, $this->password, $bd);
		if($this->conexion->connect_error){
			return "Error al conectar".$this->conexion->connect_error;
		}else{
			return "OK";
		}
	}
	function ejecutarConsulta($query){
		return $this->conexion->query($query);
	}

	function cerrarConexion(){
		$this->conexion->close();
	}

	function buscarDatos($tabla, $campo, $dato){
		$sql= "select * from ".$tabla." where ".$campo."=".$dato.";";
		return $this->ejecutarConsulta($sql);
	}

	function guardarMarca($cod, $nombre){
		$sql= "call newMarca('".$cod."', '".$nombre."');";
		return $this->ejecutarConsulta($sql);
	}

	function guardarProducto($codigo, $nombre, $talla, $marca, $cantidad, $fecha){
		$sql= "call newProducto('".$codigo."', '".$nombre."', '".$talla."', '".$marca."', '".$cantidad."', '".$fecha."');";
		return $this->ejecutarConsulta($sql);
	}

	function eliminarMarca($referencia){
		$sql="call borrarMarca('".$referencia."');";
		return $this->ejecutarConsulta($sql);
	}

	function eliminarProducto($codigo){
		$sql="call borrarProducto('".$codigo."');";
		return $this->ejecutarConsulta($sql);
	}

	function actualizarMarca($referencia, $nombre){
		$sql="call actualizarMarca('".$referencia."', '".$nombre."');";
		return $this->ejecutarConsulta($sql);
	}

	function actualizarProducto($codigo, $nombre, $talla, $marca, $cantidad, $fecha){
		$sql="call actualizarProducto('".$codigo."', '".$nombre."', '".$talla."', '".$marca."', '".$cantidad."', '".$fecha."');";
		return $this->ejecutarConsulta($sql);
	}

}


?>