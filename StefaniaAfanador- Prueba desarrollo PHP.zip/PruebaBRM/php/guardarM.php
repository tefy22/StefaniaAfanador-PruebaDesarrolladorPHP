<?php  

require 'conexion.php';

$con= new ConexionDB();

if ($con->conexion('almacen')=='OK') {
	$ref= $_POST['reference'];
	$nombre= $_POST['name'];
	$res= $con->buscarDatos('marca','referencia',$ref);
	if (mysqli_num_rows($res)==true) {
		echo "La marca se encuentra registrada!";
	}else{
		$con->guardarMarca($ref,$nombre);
		echo "Datos Guardados Satisfactoriamente!";
	}
	mysqli_free_result($res);
}else{
	echo "error en la conexion";
	$con->cerrarConexion();
}

?>